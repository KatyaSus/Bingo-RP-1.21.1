NegativeSpaceFont-master
https://github.com/AmberWat/NegativeSpaceFont
NoShadow-main
https://github.com/PuckiSilver/NoShadow